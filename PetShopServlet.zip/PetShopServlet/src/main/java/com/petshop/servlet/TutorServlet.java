package com.petshop.servlet;

import com.petshop.model.Tutor;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/tutor")
public class TutorServlet extends HttpServlet {
    private static List<Tutor> tutores = new ArrayList<>();
    private static int idCounter = 1;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.getWriter().write(tutores.toString());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String nome = req.getParameter("nome");
        Tutor tutor = new Tutor(idCounter++, nome);
        tutores.add(tutor);
        resp.setContentType("application/json");
        resp.getWriter().write(tutor.toString());
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String nome = req.getParameter("nome");

        for (Tutor tutor : tutores) {
            if (tutor.getId() == id) {
                tutor.setNome(nome);
                resp.getWriter().write(tutor.toString());
                return;
            }
        }
        resp.getWriter().write("Tutor not found");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));

        for (Tutor tutor : tutores) {
            if (tutor.getId() == id) {
                tutores.remove(tutor);
                resp.getWriter().write("true");
                return;
            }
        }
        resp.getWriter().write("false");
    }
}
