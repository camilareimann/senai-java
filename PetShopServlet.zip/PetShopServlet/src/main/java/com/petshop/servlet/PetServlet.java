package com.petshop.servlet;

import com.petshop.model.Pet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/pet")
public class PetServlet extends HttpServlet {
    private static List<Pet> pets = new ArrayList<>();
    private static int idCounter = 1;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        resp.getWriter().write(pets.toString());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String nome = req.getParameter("nome");
        int tutorId = Integer.parseInt(req.getParameter("tutorId"));
        Pet pet = new Pet(idCounter++, nome, tutorId);
        pets.add(pet);
        resp.setContentType("application/json");
        resp.getWriter().write(pet.toString());
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String nome = req.getParameter("nome");
        int tutorId = Integer.parseInt(req.getParameter("tutorId"));

        for (Pet pet : pets) {
            if (pet.getId() == id) {
                pet.setNome(nome);
                pet.setTutorId(tutorId);
                resp.getWriter().write(pet.toString());
                return;
            }
        }
        resp.getWriter().write("Pet not found");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));

        for (Pet pet : pets) {
            if (pet.getId() == id) {
                pets.remove(pet);
                resp.getWriter().write("true");
                return;
            }
        }
        resp.getWriter().write("false");
    }
}
